
class Student implements Comparable<Student> {
        Long studentID;
        String name;
        Double avgGrade;
    public Student(double avgGrade, String name, long studentID) {
        this.avgGrade = avgGrade;
        this.name = name;
        this.studentID = studentID;
    }

    @Override
    public int compareTo(Student otherStudent) {
        int comparisonVal;

        comparisonVal = avgGrade.compareTo((otherStudent.avgGrade));

        if (comparisonVal == 0) {
            comparisonVal = name.compareTo(otherStudent.name);
            if (comparisonVal != 0) {
                return -1 * comparisonVal;
            }
        }
        return comparisonVal;
    }

    @Override
    public String toString() {
        return name + "\t\tStudent ID: " + studentID + "\t\tQuiz Grade: " + avgGrade;
    }
}
